package com.cg.report.exception;

public class ReportServicesDownException extends Exception{

	public ReportServicesDownException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ReportServicesDownException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public ReportServicesDownException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public ReportServicesDownException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ReportServicesDownException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
