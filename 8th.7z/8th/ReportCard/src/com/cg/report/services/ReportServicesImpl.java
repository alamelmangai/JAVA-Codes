package com.cg.report.services;

import java.util.List;

import com.cg.report.beans.Student;
import com.cg.report.beans.Subject;
import com.cg.report.daoservices.ReportCardDAOServices;
import com.cg.report.daoservices.ReportCardDAOServicesImpl;
import com.cg.report.exception.ReportServicesDownException;
import com.cg.report.exception.StudentNotFoundException;
import com.cg.report.exception.SubjectNotFoundException;

public class ReportServicesImpl implements ReportCardServices {
	private ReportCardDAOServices daoServices = new ReportCardDAOServicesImpl() ;
	@Override
	public int acceptStudentDetails(String firstName, String lastName, String stream, String emailId, String address,
			String dateOfBirth) throws ReportServicesDownException {
		return daoServices.insertStudent(new Student( firstName, lastName, stream, emailId, address, dateOfBirth));
	}

	@Override
	public int markCalculation(int subjectId, int studentId) throws StudentNotFoundException,ReportServicesDownException, SubjectNotFoundException {
		Student student = this.getStudentDetails(subjectId);
		if(student!=null)
			this.getSubjectDetails(studentId, subjectId).setMark(60);
		this.getSubjectDetails(studentId, subjectId).setMark(75);
		this.getSubjectDetails(studentId, subjectId).setMark(70);
		this.getSubjectDetails(studentId, subjectId).setMark(81);
		this.getSubjectDetails(studentId, subjectId).setMark(73);
		return 0;

	}

	@Override
	public int percentageCalculation(int studentId) throws StudentNotFoundException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int gradeCalculation(int studentId) throws StudentNotFoundException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Student getStudentDetails(int studentId) throws StudentNotFoundException, ReportServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Subject getSubjectDetails(int studentId, int subjectId)
			throws StudentNotFoundException, ReportServicesDownException, SubjectNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> getAllStudentDetails() throws ReportServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Subject> getAllSubjectDetails(int studentId)
			throws ReportServicesDownException, StudentNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteStudent(int studentId) throws ReportServicesDownException, StudentNotFoundException {
		// TODO Auto-generated method stub
		return false;
	}

}
