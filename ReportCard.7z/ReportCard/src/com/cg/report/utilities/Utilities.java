package com.cg.report.utilities;

public class Utilities {
	public static int STUDENT_ID_COUNTER=1;
	public static int SUBJECT_ID_COUNTER=1;
}
