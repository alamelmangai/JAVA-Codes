﻿<!DOCTYPE html>
<html>
<body>

<?php
echo "YOUR ORDER IS PLACES  "<br>;
echo "ENJOY YOUR ORDER " <br>;
echo "ORDER WILL REACH IN 30 MINs."<br>;
?>

</body>
</html>