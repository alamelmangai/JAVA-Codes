package com.cg.payroll.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.PayrollServicesDownExceptions;
import com.cg.payroll.utility.PayrollUtility;
@Component(value="DAOServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices{
	@Autowired
    private JdbcTemplate jdbcTemplate;
	/*private static final String associateID = null;
	private Connection con = null;
	public PayrollDAOServicesImpl() throws PayrollServicesDownExceptions{
		con = PayrollUtility.getDBConnection();
	}*/
	@Override
	public int insertAssociate(Associate associate) throws SQLException {
		String sql = "insert into Associate(yearlyInvestmentUnder80C,firstName,lastName,department,designation,pancard,emailId) value(?,?,?,?,?,?,?)";
		int associateId = jdbcTemplate.update(sql, new Object[] {associate.getYearlyInvestmentUnder80C(),associate.getFirstName(),associate.getLastName(),associate.getDepartment(),associate.getDesignation(),associate.getPancard(),associate.getEmailId()});
		String sql1 = "insert into Salary(associateId,basicSalary,epf,companyPf) value(?,?,?,?)";
		jdbcTemplate.update(sql1, new Object[] {associateId,associate.getSalary().getBasicSalary(),associate.getSalary().getEpf(),associate.getSalary().getCompanyPf()});
		String sql2 = "insert into BankDetails(associateId,accountNo,bankName,ifscCode) value(?,?,?,?)";
		jdbcTemplate.update(sql2, new Object[] {associateId,associate.getBankDetail().getAccountNumber(),associate.getBankDetail().getBankName(),associate.getBankDetail().getIfscCode()});
		return associateId;
	}		
		
		/*try { 
			con.setAutoCommit(false);
			PreparedStatement pstmt1 = con.prepareStatement("insert into Associate (yearlyInvestmentUnder80C,firstName,lastName,department,designation,pancard,emailId) value(?,?,?,?,?,?,?)"); 
			pstmt1.setFloat(1, associate.getYearlyInvestmentUnder80C());
			pstmt1.setString(2, associate.getFirstName());
			pstmt1.setString(3, associate.getLastName());
			pstmt1.setString(4, associate.getDepartment());
			pstmt1.setString(5, associate.getDesignation());
			pstmt1.setString(6, associate.getPancard());
			pstmt1.setString(7, associate.getEmailId());
			pstmt1.executeUpdate();
			
			PreparedStatement pstmt2 = con.prepareStatement("select max(associateId) from Associate");
			
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int associateId = rs.getInt(1);
			
			
			PreparedStatement pstmt3 = con.prepareStatement("insert into Salary(associateId,basicSalary,epf,companyPf) values(?,?,?,?)");
			pstmt3.setInt(1, associateId);
			pstmt3.setFloat(2, associate.getSalary().getBasicSalary());
			pstmt3.setFloat(3, associate.getSalary().getEpf());
			pstmt3.setFloat(4, associate.getSalary().getCompanyPf());
			pstmt3.executeUpdate();
			
			PreparedStatement pstmt4 = con.prepareStatement("insert into BankDetails(associateId,accountNumber,bankName,ifscCode)values(?,?,?,?)");
			pstmt4.setInt(1, associateId);
			pstmt4.setInt(2, associate.getBankDetail().getAccountNumber());
			pstmt4.setString(3, associate.getBankDetail().getBankName());
			pstmt4.setString(4, associate.getBankDetail().getIfscCode());
			pstmt4.executeUpdate();
			
			con.commit();
			return associateId;
		}
		catch (SQLException e) {
			con.rollback();
			throw e;
		}
		finally {
			con.setAutoCommit(true);
		}*/
		

	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {
		/*try {
			con.setAutoCommit(false);
			PreparedStatement pstmt1=con.prepareStatement("update Associate set yearlyInvestmentUnder80C=?,firstName=?,lastName=?,department=?,designation=?,pancard=?,emailId=? where associateID=?");
			pstmt1.setFloat(1, associate.getYearlyInvestmentUnder80C());
			pstmt1.setString(2,associate.getFirstName());
			pstmt1.setString(3,associate.getLastName());
			pstmt1.setString(4,associate.getDepartment());
			pstmt1.setString(5, associate.getDesignation());
			pstmt1.setString(6, associate.getPancard());
			pstmt1.setString(7, associate.getEmailId());
			pstmt1.setInt(8,associate.getAssociateID());
			pstmt1.executeUpdate();

			PreparedStatement pstmt2=con.prepareStatement("update BankDetails set accountNumber=?, bankName=?,ifscCode=? where associateID=?");
			pstmt2.setInt(1, associate.getBankDetail().getAccountNumber());
			pstmt2.setString(2, associate.getBankDetail().getBankName());
			pstmt2.setString(3, associate.getBankDetail().getIfscCode());
			pstmt2.setInt(4, associate.getAssociateID());
			pstmt2.executeUpdate();

			PreparedStatement pstmt3=con.prepareStatement("update Salary set basicSalary=?, hra=?, conveyenceAllowance=?, otherAllowance=?,personalAllowance=?,monthlyTax=?,epf=?, companyPf=?,gratuity=?,grossSalary=?,netSalary=? where associateID=?");
			pstmt3.setFloat(1, associate.getSalary().getBasicSalary());
			pstmt3.setFloat(2, associate.getSalary().getHra());
			pstmt3.setFloat(3, associate.getSalary().getConveyenceAllowance());
			pstmt3.setFloat(4, associate.getSalary().getOtherAllowance());
			pstmt3.setFloat(5, associate.getSalary().getPersonalAllowance());
			pstmt3.setFloat(6, associate.getSalary().getMonthlyTax());
			pstmt3.setFloat(7, associate.getSalary().getEpf());
			pstmt3.setFloat(8, associate.getSalary().getCompanyPf());
			pstmt3.setFloat(9, associate.getSalary().getGratuity());
			pstmt3.setFloat(10, associate.getSalary().getGrossSalary());
			pstmt3.setFloat(11, associate.getSalary().getNetSalary());
			pstmt3.setInt(12, associate.getAssociateID());
			pstmt3.executeUpdate();

			con.commit();
			return true;
		} catch (SQLException e) {
			con.rollback();
			e.printStackTrace();
		}
		finally {
			con.setAutoCommit(true);
		}
*/

		return false;
	}
	public boolean deleteAssociate(int associateID) throws SQLException {
			
			/*try {
				PreparedStatement pstmt=con.prepareStatement("delete from Associate where associateID=?");
				pstmt.setInt(1, associateID);
				pstmt.executeUpdate();
				return true;
			} catch (SQLException e) {
				e.printStackTrace();
			}
			*/
			return false;
		} 
	
	@Override
	public Associate getAssociate(int associateID) throws SQLException  {
	/*	PreparedStatement pstmt=con.prepareStatement("select a.associateID,a.yearlyInvestmentUnder80C,a.firstName,a.lastName,a.department,a.designation,a.pancard,a.emailId,b.accountNumber,b.bankName,b.ifscCode,s.basicSalary, s.hra, s.conveyenceAllowance, s.otherAllowance,s.personalAllowance,s.monthlyTax,s.epf,s.companyPf,s.gratuity,s.grossSalary,s.netSalary\r\n" + 
				"from Associate a inner join BankDetails b inner join Salary s \r\n" + 
				"on a.associateId=b.associateId and a.associateID=s.associateID\r\n" + 
				"where a.associateID=? ");
		pstmt.setInt(1, associateID);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()) {
			return new Associate(new Salary(rs.getFloat("basicSalary"), rs.getFloat("hra"),rs.getFloat( "conveyenceAllowance"), rs.getFloat("otherAllowance"), rs.getFloat("personalAllowance"), rs.getFloat("monthlyTax"), rs.getFloat("epf"), rs.getFloat("companyPf"), rs.getFloat("gratuity"), rs.getFloat("grossSalary"), rs.getFloat("netSalary")), new BankDetails(rs.getInt("accountNumber"), rs.getString("bankName"), rs.getString("ifscCode")),associateID,rs.getInt("yearlyInvestmentUnder80C"), rs.getString("firstName"),rs.getString("lastName"), rs.getString("department"), rs.getString("designation"),rs.getString("pancard"),rs.getString("emailId"));
		}*/
		return null;
	}
	@Override
	public List<Associate> getAssociates() {
		/*try {
			PreparedStatement pstmt=con.prepareStatement("select a.associateID,a.yearlyInvestmentUnder80C,a.firstName,a.lastName,a.department,a.designation,a.pancard,a.emailId,b.accountNumber,b.bankName,b.ifscCode,s.basicSalary, s.hra, s.conveyenceAllowance, s.otherAllowance,s.personalAllowance,s.monthlyTax,s.epf,s.companyPf,s.gratuity,s.grossSalary,s.netSalary\r\n" + 
					"from Associate a inner join BankDetails b inner join Salary s \r\n" + 
					"on a.associateId=b.associateId and a.associateID=s.associateID ");
			ResultSet rs=pstmt.executeQuery();
			List<Associate> associates=new ArrayList<>();
			while(rs.next()) {
				associates.add(new Associate(new Salary(rs.getFloat("basicSalary"), rs.getFloat("hra"), rs.getFloat("conveyenceAllowance"), rs.getFloat("otherAllowance"), rs.getFloat("personalAllowance"), rs.getFloat("monthlyTax"), rs.getFloat("epf"), rs.getFloat("companyPf"), rs.getFloat("gratuity"), rs.getFloat("grossSalary"), rs.getFloat("netSalary")), new BankDetails(rs.getInt("accountNumber"), rs.getString("bankName"), rs.getString("ifscCode")), rs.getInt("associateID"), rs.getInt("yearlyInvestmentUnder80C"), rs.getString("firstName"), rs.getString("lastName"), rs.getString("department"), rs.getString("designation"), rs.getString("pancard"), rs.getString("emailId")));
			}
			return associates;
		} catch (SQLException e) {
	
			e.printStackTrace();
		}*/
	return null;
	}


}
