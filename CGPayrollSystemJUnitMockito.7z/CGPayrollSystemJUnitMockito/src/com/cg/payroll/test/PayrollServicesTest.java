package com.cg.payroll.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;

public class PayrollServicesTest {
	private static PayrollServices  payrollServices;
	private static PayrollDAOServices mockDAOServices;

	@BeforeClass
	public static void setUpTestEnv() {
		mockDAOServices=Mockito.mock(PayrollDAOServices.class);
		payrollServices=new PayrollServicesImpl(mockDAOServices);
	}
	
	@Before
	public void setUpMockData() {
		Associate associate1= new Associate(111, 150000,  "abi", "c", "hr", "chief", "a1", "abi@abcd.com",new Salary(300000, 1000, 1000),new BankDetails(45698, "sbi", "sbi1"));
		Associate associate2= new Associate(112, 300000,  "satish", "mahajan", "taining", "dev", "s1", "satish@abcd.com",new Salary(50000, 1000, 1000),new BankDetails(2369, "hdfc", "hdfc1"));
		
		HashMap<Integer, Associate> associateList=new HashMap<>();
		associateList.put(111, associate1);
		associateList.put(112, associate2);
		Mockito.when(mockDAOServices.getAssociate(111)).thenReturn(associate1);
		Mockito.when(mockDAOServices.getAssociate(112)).thenReturn(associate2);
		Associate associate3= new Associate( 400000,  "akash", "gupta", "taining", "dev", "s1", "akash@abcd.com",new Salary(60000, 1000, 1000),new BankDetails(36357, "idbi", "idbi1"));
		Mockito.when(mockDAOServices.insertAssociate(associate3)).thenReturn(113);
		Mockito.when(mockDAOServices.getAssociates()).thenReturn(new ArrayList(associateList.values()));
		Mockito.when(mockDAOServices.getAssociate(1234)).thenReturn(null);
	}
	
	@Test(expected = AssociateDetailsNotFoundException.class)
	public void testGetAssociateDataForInvalidAssociateId()
			throws PayrollServicesDownException, AssociateDetailsNotFoundException {
		payrollServices.getAssociateDetails(1234);
	}
	
	@Test
	public void acceptAssociateDetailsForValidData() throws PayrollServicesDownException {
		int expectedAssociateID=113;
		int  actualAssociateID=payrollServices.acceptAssociateDetails( "akash","gupta", "akash@abcd.com",  "taining", "dev",  "s1",  400000, 60000, 1000, 1000, 36357, "idbi", "idbi1");
		assertEquals(expectedAssociateID, actualAssociateID);
	}
	
	@Test
	public void testGetAssociateDetailsForValidAssociateID() throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		Associate expectedAssociate=new Associate(111, 150000,  "abi", "c", "hr", "chief", "a1", "abi@abcd.com",new Salary(300000, 1000, 1000),new BankDetails(45698, "sbi", "sbi1"));
		Associate actualAssociate=payrollServices.getAssociateDetails(111);
		assertEquals(expectedAssociate, actualAssociate);
		Mockito.verify(mockDAOServices).getAssociate(111);
	}
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDetailsForInValidAssociateID() throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		payrollServices.getAssociateDetails(114);
		Mockito.verify(mockDAOServices).getAssociate(114);
	}
	
	@Test
	public void testCalculateNetSalaryForValidAssociateID() throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		assertEquals(354733,payrollServices.calculateNetSalary(111));
	}
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testCalculateNetSalaryForInValidAssociateID() throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		payrollServices.calculateNetSalary(114);
	}
	
	@Test
	public void testGetAllAssociatesDetails() throws PayrollServicesDownException {
		payrollServices.getAllAssociatesDetails();
		}
	
	@After
	public void tearDownMockData() {
	Mockito.reset(mockDAOServices);
	}
	
	@AfterClass
	public static void tearDownTestEnv() {
			payrollServices=null;
	}

}
