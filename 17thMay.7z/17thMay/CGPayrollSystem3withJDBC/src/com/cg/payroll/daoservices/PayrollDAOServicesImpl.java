package com.cg.payroll.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.PayrollServicesDownExceptions;
import com.cg.payroll.utility.PayrollUtility;

public class PayrollDAOServicesImpl implements PayrollDAOServices{

	private Connection con = null;
	public PayrollDAOServicesImpl() throws PayrollServicesDownExceptions{
		con = PayrollUtility.getDBConnection();
	}
	@Override
	public int insertAssociate(Associate associate) throws SQLException {
		
		try { 
			con.setAutoCommit(false);
			PreparedStatement pstmt1 = con.prepareStatement("insert into Associate (yearlyInvestmentUnder80C,firstName,lastName,department,designation,pancard,emailId) value(?,?,?,?,?,?,?)"); 
			pstmt1.setFloat(1, associate.getYearlyInvestmentUnder80C());
			pstmt1.setString(2, associate.getFirstName());
			pstmt1.setString(3, associate.getLastName());
			pstmt1.setString(4, associate.getDepartment());
			pstmt1.setString(5, associate.getDesignation());
			pstmt1.setString(6, associate.getPancard());
			pstmt1.setString(7, associate.getEmailId());
			pstmt1.executeUpdate();
			
			PreparedStatement pstmt2 = con.prepareStatement("select max(associateId) from Associate");
			
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int associateId = rs.getInt(1);
			
			
			PreparedStatement pstmt3 = con.prepareStatement("insert into Salary(associateId,basicSalary,epf,companyPf) values(?,?,?,?)");
			pstmt3.setInt(1, associateId);
			pstmt3.setFloat(2, associate.getSalary().getBasicSalary());
			pstmt3.setFloat(3, associate.getSalary().getEpf());
			pstmt3.setFloat(4, associate.getSalary().getCompanyPf());
			pstmt3.executeUpdate();
			
			PreparedStatement pstmt4 = con.prepareStatement("insert into BankDetails(associateId,accountNumber,bankName,ifscCode)values(?,?,?,?)");
			pstmt4.setInt(1, associateId);
			pstmt4.setInt(2, associate.getBankDetail().getAccountNumber());
			pstmt4.setString(3, associate.getBankDetail().getBankName());
			pstmt4.setString(4, associate.getBankDetail().getIfscCode());
		
			pstmt4.executeUpdate();
			con.commit();
			return associateId;
		}
		catch (SQLException e) {
			con.rollback();
			throw e;
		}
		finally {
			con.setAutoCommit(true);
		}
		
	}

	@Override
	public boolean updateAssociate(Associate associate) {
		try { 
			con.setAutoCommit(false);
			PreparedStatement pstmt1 = con.prepareStatement("update Associate set yearlyInvestmentUnder80C=?,firstName=?,lastName=?,department=?,designation=?,pancard=?,emailId=? where associateID=?"); 
			pstmt1.setFloat(1, associate.getYearlyInvestmentUnder80C());
			pstmt1.setString(2, associate.getFirstName());
			pstmt1.setString(3, associate.getLastName());
			pstmt1.setString(4, associate.getDepartment());
			pstmt1.setString(5, associate.getDesignation());
			pstmt1.setString(6, associate.getPancard());
			pstmt1.setString(7, associate.getEmailId());
			pstmt1.executeUpdate();
			
			PreparedStatement pstmt3 = con.prepareStatement("insert into Salary(associateId,basicSalary,epf,companyPf) values(?,?,?,?)");
			pstmt3.setInt(1, associateID);
			pstmt3.setFloat(2, associate.getSalary().getBasicSalary());
			pstmt3.setFloat(3, associate.getSalary().getEpf());
			pstmt3.setFloat(4, associate.getSalary().getCompanyPf());
			pstmt3.executeUpdate();
			
			PreparedStatement pstmt4 = con.prepareStatement("insert into BankDetails(associateId,accountNumber,bankName,ifscCode)values(?,?,?,?)");
			pstmt4.setInt(1, associateId);
			pstmt4.setInt(2, associate.getBankDetail().getAccountNumber());
			pstmt4.setString(3, associate.getBankDetail().getBankName());
			pstmt4.setString(4, associate.getBankDetail().getIfscCode());
		
			pstmt4.executeUpdate();
		}
		catch (SQLException e) {
			con.rollback();
			throw e;
		}
		finally {
			con.setAutoCommit(true);
		}
		
		return false;
	}

	@Override
	public boolean deleteAssociate(int associateId) {
	
		return false;
	}

	@Override
	public Associate getAssociate(int associateId) {

		return null;
	}

	@Override
	public List<Associate> getAssociate() {
	
		return null;
	}

}
