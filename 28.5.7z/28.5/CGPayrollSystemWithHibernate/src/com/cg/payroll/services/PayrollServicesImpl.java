package com.cg.payroll.services;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundExceptions;
import com.cg.payroll.exceptions.PayrollServicesDownExceptions;
@Component(value="Services")
public class PayrollServicesImpl implements PayrollServices {
@Autowired
	private PayrollDAOServices daoServices;
	/*public PayrollServicesImpl() throws PayrollServicesDownExceptions{
		daoServices = new PayrollDAOServicesImpl();
	}*/
	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String department, 
			String designation,String pancard, String emailId,float yearlyInvestmentUnder80C,
			float basicSalary, float epf, float companyPf,
			int accountNumber,String bankName,String ifscCode) throws PayrollServicesDownExceptions{
		return daoServices.insertAssociate(new Associate(new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode), yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId));
	}
	@Override
	public float calculateNetSalary(int associateId) throws AssociateDetailsNotFoundExceptions,PayrollServicesDownExceptions{
		return 0;
	}

	@Override
	public boolean deleteAssociate(int associateID)throws PayrollServicesDownExceptions{
		return daoServices.deleteAssociate(associateID);
	}
	
	public Associate getAssociateDetails(int associateID)
			throws AssociateDetailsNotFoundExceptions, PayrollServicesDownExceptions{
		Associate associate;
		associate = daoServices.getAssociate(associateID);
		if(associate==null){
			AssociateDetailsNotFoundExceptions ex=
					new AssociateDetailsNotFoundExceptions("Associate details not found for "+associateID);
		throw ex;
		}
			return associate;
	}
	
	@Override
	public List<Associate> getAllAssociateDetails()throws PayrollServicesDownExceptions{
		return daoServices.getAssociates();
	}
	
	@Override
	public boolean updateAssociate(Associate associate) throws PayrollServicesDownExceptions {
		return daoServices.updateAssociate(associate);
	}
	
}
