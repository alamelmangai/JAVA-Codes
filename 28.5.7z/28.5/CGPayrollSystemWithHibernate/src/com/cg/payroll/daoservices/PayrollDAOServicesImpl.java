package com.cg.payroll.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.PayrollServicesDownExceptions;
import com.cg.payroll.utility.AssociateMapper;
import com.cg.payroll.utility.PayrollUtility;
@Component(value="payrollDAOServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices{
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public int insertAssociate(Associate associate) {
	
		return 0;
	}

	@Override
	public boolean updateAssociate(Associate associate) {
	
		return false;
	}

	@Override
	public boolean deleteAssociate(int associateId) {
	
		return false;
	}

	@Override
	public Associate getAssociate(int associateId) {
	
		return null;
	}

	@Override
	public List<Associate> getAssociates()  {

		return null;
	}
	

}
