package com.cg.report.daoservices;
import java.util.List;
import com.cg.report.beans.Student;
import com.cg.report.beans.Subject;

public interface ReportCardDAOServices {
	
	int insertStudent(Student student);
	
	int insertSubject(int studentId,Subject student);

	boolean updateStudent(Student student);

	boolean deleteStudent(int studentsId);

	Student getStudent(int studentId);
	
	Subject getSubject(int studentId,String subjectId);

	List<Student> getStudent();
	
	List<Subject> getSubject(int studentId);

}

