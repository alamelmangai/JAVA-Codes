package com.cg.payroll.test;
import static org.junit.Assert.*;
import java.security.Provider.Service;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;
import org.omg.PortableServer.Servant;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundExceptions;
import com.cg.payroll.exceptions.PayrollServicesDownExceptions;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class PayrollServicesTest {
	public static PayrollServices payrollServices;
	public static PayrollDAOServices mockDAOServices;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		mockDAOServices=Mockito.mock(PayrollDAOServices.class);
		payrollServices=new PayrollServicesImpl(mockDAOServices); 
	}
	@Before
	public void setUp() throws Exception {
	
	}
	@Test
	public void testToAcceptAssociateDetails() throws Exception{
		
	}
	@Test(expected=AssociateDetailsNotFoundExceptions.class)
	public void testAssociateDetailsNotFound() throws Exception{
		
	}
	@Test
	public void testAssociateIdFound() throws Exception{
		
	}
	@Test
	public void associateDetailsFound() throws Exception{
		
	   
	}
	@Test
	public void  testCalculateNetSalary() throws Exception{
	
	
	}
	@Test
	public void testGetAllAssociates() throws Exception{
		
	}
	@Test
	public void testDeleteAssociate() throws Exception{
	
	}
	@Test(expected=AssociateDetailsNotFoundExceptions.class)
	public void testDeleteNotAssociate() throws Exception{
	
	}
	@After
	public void tearDown() throws Exception {
		
	}
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		
	}


	//@Test
	//public void test() {
	//	fail("Not yet implemented");
	//}

}
