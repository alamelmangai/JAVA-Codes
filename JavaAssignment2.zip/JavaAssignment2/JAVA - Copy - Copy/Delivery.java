package com.cg.pizza.beans;

public class Delivery {
	private String dateOfdelivery,deliveryStatus;

	public Delivery(String dateOfdelivery, String deliveryStatus) {
		super();
		this.dateOfdelivery = dateOfdelivery;
		this.deliveryStatus = deliveryStatus;
	}

	public String getDateOfdelivery() {
		return dateOfdelivery;
	}

	public void setDateOfdelivery(String dateOfdelivery) {
		this.dateOfdelivery = dateOfdelivery;
	}

	public String getDeliveryStatus() {
		return deliveryStatus;
	}

	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	


}
