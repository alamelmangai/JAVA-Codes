package com.cg.pizza.beans;

public class Customer {
	private int customerId,Mobile;
	private String customerName;
	public Customer(int customerId, int mobile, String customerName) {
		super();
		this.customerId = customerId;
		Mobile = mobile;
		this.customerName = customerName;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getMobile() {
		return Mobile;
	}
	public void setMobile(int mobile) {
		Mobile = mobile;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
}