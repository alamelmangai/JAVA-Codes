package com.cg.pizza.beans;

public class Order {
	private String pizzaName,pizzaType,pizzaBase,toppings,sides;
	private int orderNo,orderId;
	public Order(String pizzaName, String pizzaType, String pizzaBase, String toppings, String sides, int orderNo,
			int orderId) {
		super();
		this.pizzaName = pizzaName;
		this.pizzaType = pizzaType;
		this.pizzaBase = pizzaBase;
		this.toppings = toppings;
		this.sides = sides;
		this.orderNo = orderNo;
		this.orderId = orderId;
	}
	public String getPizzaName() {
		return pizzaName;
	}
	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}
	public String getPizzaType() {
		return pizzaType;
	}
	public void setPizzaType(String pizzaType) {
		this.pizzaType = pizzaType;
	}
	public String getPizzaBase() {
		return pizzaBase;
	}
	public void setPizzaBase(String pizzaBase) {
		this.pizzaBase = pizzaBase;
	}
	public String getToppings() {
		return toppings;
	}
	public void setToppings(String toppings) {
		this.toppings = toppings;
	}
	public String getSides() {
		return sides;
	}
	public void setSides(String sides) {
		this.sides = sides;
	}
	public int getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	

}
