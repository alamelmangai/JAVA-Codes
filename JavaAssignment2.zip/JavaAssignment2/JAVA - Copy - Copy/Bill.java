package com.cg.pizza.beans;

public class Bill {
	private int totNoOfItems,totCost,stateGST,centralGST,serviceTax,deliveryCharge;

	public Bill(int totNoOfItems, int totCost, int stateGST, int centralGST, int serviceTax, int deliveryCharge) {
		super();
		this.totNoOfItems = totNoOfItems;
		this.totCost = totCost;
		this.stateGST = stateGST;
		this.centralGST = centralGST;
		this.serviceTax = serviceTax;
		this.deliveryCharge = deliveryCharge;
	}

	public int getTotNoOfItems() {
		return totNoOfItems;
	}

	public void setTotNoOfItems(int totNoOfItems) {
		this.totNoOfItems = totNoOfItems;
	}

	public int getTotCost() {
		return totCost;
	}

	public void setTotCost(int totCost) {
		this.totCost = totCost;
	}

	public int getStateGST() {
		return stateGST;
	}

	public void setStateGST(int stateGST) {
		this.stateGST = stateGST;
	}

	public int getCentralGST() {
		return centralGST;
	}

	public void setCentralGST(int centralGST) {
		this.centralGST = centralGST;
	}

	public int getServiceTax() {
		return serviceTax;
	}

	public void setServiceTax(int serviceTax) {
		this.serviceTax = serviceTax;
	}

	public int getDeliveryCharge() {
		return deliveryCharge;
	}

	public void setDeliveryCharge(int deliveryCharge) {
		this.deliveryCharge = deliveryCharge;
	}
	

}
