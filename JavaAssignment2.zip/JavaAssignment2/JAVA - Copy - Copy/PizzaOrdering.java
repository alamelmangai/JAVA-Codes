package com.cg.pizza.main;

import com.cg.pizza.beans.Address;
import com.cg.pizza.beans.Bill;
import com.cg.pizza.beans.Customer;
import com.cg.pizza.beans.Delivery;
import com.cg.pizza.beans.Discount;
import com.cg.pizza.beans.Order;
import com.cg.pizza.beans.Transaction;

public class PizzaOrdering {

	public static void main(String[] args) {
		Customer customer = new Customer(1001, 22289081, "alamel");
		Order order = new Order("Cheese corn", "veg", "pan base", "corn and cheese", "cococola", 23, 1234);
		Delivery delivery = new Delivery("12-08-2018", "Delivered");
		Discount discount = new Discount(20, "buy one get one", "17-8-2018", "DOMINOS12");
		Address address = new Address(600045, "Chennai", "TamilNadu", "India");
		Transaction transaction = new Transaction("Card", "Success", "12-8-2018", 540);
		Bill bill = new Bill(3, 540, 12, 12, 30, 100);
		System.out.println(customer.getCustomerName()+order.getOrderNo()+delivery.getDeliveryStatus()+transaction.getModeOfTransaction()+order.getPizzaName()+bill.getDeliveryCharge()+discount.getDiscountcode());
		
	}

}
