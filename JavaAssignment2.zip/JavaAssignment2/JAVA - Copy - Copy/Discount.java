package com.cg.pizza.beans;

public class Discount {
	private int discountrate;
	private String typeofdiscount,discountvaliditydate,discountcode;
	public Discount(int discountrate, String typeofdiscount, String discountvaliditydate, String discountcode) {
		super();
		this.discountrate = discountrate;
		this.typeofdiscount = typeofdiscount;
		this.discountvaliditydate = discountvaliditydate;
		this.discountcode = discountcode;
	}
	public int getDiscountrate() {
		return discountrate;
	}
	public void setDiscountrate(int discountrate) {
		this.discountrate = discountrate;
	}
	public String getTypeofdiscount() {
		return typeofdiscount;
	}
	public void setTypeofdiscount(String typeofdiscount) {
		this.typeofdiscount = typeofdiscount;
	}
	public String getDiscountvaliditydate() {
		return discountvaliditydate;
	}
	public void setDiscountvaliditydate(String discountvaliditydate) {
		this.discountvaliditydate = discountvaliditydate;
	}
	public String getDiscountcode() {
		return discountcode;
	}
	public void setDiscountcode(String discountcode) {
		this.discountcode = discountcode;
	}
    

}
