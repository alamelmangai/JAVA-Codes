package com.cg.onlinetokry.main;

import com.cg.onlinetokry.beans.Bill;
import com.cg.onlinetokry.beans.Customer;
import com.cg.onlinetokry.beans.DeliveryDetails;
import com.cg.onlinetokry.beans.Items;
import com.cg.onlinetokry.beans.Transaction;

public class MainClass {

	public static void main(String[] args) {
		Customer customer=new Customer("Walter", 9876543215l, 1867);
		DeliveryDetails deliveryDetails=new DeliveryDetails("Pune", "Maharashtra", "India", "20/04/2018", "Out for delivery", 411065);
		Bill bill=new Bill(1, 100, 50);
		Items items=new Items("Babycorn", "Available", 2, 100);
		Transaction transaction=new Transaction("Cash", "In progress", "20/04/2018", 100);
		System.out.println("Customer Name : "+customer.getName()+"\nItem Purchased : "+items.getItemName()+"\nTotal Cost : "+bill.getTotCost());
	}

}
