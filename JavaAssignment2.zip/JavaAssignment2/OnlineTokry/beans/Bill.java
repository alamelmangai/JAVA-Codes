package com.cg.onlinetokry.beans;

public class Bill {
	private int totNoOfItems,totCost,deliveryCharge;

	public Bill(int totNoOfItems, int totCost, int deliveryCharge) {
		super();
		this.totNoOfItems = totNoOfItems;
		this.totCost = totCost;
		this.deliveryCharge = deliveryCharge;
	}

	public int getTotNoOfItems() {
		return totNoOfItems;
	}

	public void setTotNoOfItems(int totNoOfItems) {
		this.totNoOfItems = totNoOfItems;
	}

	public int getTotCost() {
		return totCost;
	}

	public void setTotCost(int totCost) {
		this.totCost = totCost;
	}

	public int getDeliveryCharge() {
		return deliveryCharge;
	}

	public void setDeliveryCharge(int deliveryCharge) {
		this.deliveryCharge = deliveryCharge;
	}

}
