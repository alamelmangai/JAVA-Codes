package com.cg.onlinetokry.beans;

public class Transaction {
	private String modeoftransaction,transactionstatus,transactiondate;
	private int transactionamount;
	public Transaction(String modeoftransaction, String transactionstatus, String transactiondate,
			int transactionamount) {
		super();
		this.modeoftransaction = modeoftransaction;
		this.transactionstatus = transactionstatus;
		this.transactiondate = transactiondate;
		this.transactionamount = transactionamount;
	}
	public String getModeoftransaction() {
		return modeoftransaction;
	}
	public void setModeoftransaction(String modeoftransaction) {
		this.modeoftransaction = modeoftransaction;
	}
	public String getTransactionstatus() {
		return transactionstatus;
	}
	public void setTransactionstatus(String transactionstatus) {
		this.transactionstatus = transactionstatus;
	}
	public String getTransactiondate() {
		return transactiondate;
	}
	public void setTransactiondate(String transactiondate) {
		this.transactiondate = transactiondate;
	}
	public int getTransactionamount() {
		return transactionamount;
	}
	public void setTransactionamount(int transactionamount) {
		this.transactionamount = transactionamount;
	}
	
}
