package com.cg.onlinetokry.beans;

public class Customer {
	private String name;
	private long mobileNo;
	private int customerID;
	public Customer(String name, long mobileNo, int customerID) {
		super();
		this.name = name;
		this.mobileNo = mobileNo;
		this.customerID = customerID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

}
