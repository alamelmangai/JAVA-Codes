package com.cg.banking.beans;
public class Account {
	private int accountBlance,accountNo;;
	private String accountType;
	public Account(int accountBlance, int accountNo, String accountType) {
		super();
		this.accountBlance = accountBlance;
		this.accountNo = accountNo;
		this.accountType = accountType;
	}
	public int getAccountBlance() {
		return accountBlance;
	}
	public void setAccountBlance(int accountBlance) {
		this.accountBlance = accountBlance;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
}


