package com.cg.banking.main;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class MainClass {

	public static void main(String[] args) {
		System.out.println(Customer.UNIVERSAL_CUSTOMERS);
		Customer customer1 = new Customer(1234, 74125896, 12457, "Aishwarya", "Patil", "abc@java.com", "avfc456", "25/11/94");
		Customer customer2 = new Customer(7456, 125473632, 741258, "Akarsh", "Patil", "abg@java.com", "154543wg", "05/05/99");
		Address addrerss = new Address(590006, "Belagavi", "Karnataka", "India");
		Account account = new Account(60000, 144785233, "saving");
		Transaction transaction = new Transaction(1234, 1000, "02:15:20:02", "Deposit", "Belagavi", "Cash", "Completed");
		System.out.println(Customer.UNIVERSAL_CUSTOMERS);
		System.out.println("Customer Name :"+customer1.getFirstName()+"  Email Id :" +customer2.getEmailId()+ "  City:"+addrerss.getCity()+"  Account type :" +account.getAccountBlance()+"  Ammount: "+transaction.getAmount());
		
	}

}
