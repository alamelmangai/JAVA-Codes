package com.cg.eventmanagement.main;

import com.cg.eventmanagement.beans.*;

public class MainClass {

	public static void main(String[] args) {
	Customer customer=new Customer("Sachin", 9876543219l);
	Catering catering=new Catering("In Progress", "Per Plate", 200);
	EventDetails eventDetails=new EventDetails("Pune", "Maharashtra", "India", "Wedding", "09/05/2018", "12/05/2018", 411062, 30000, 3, 150);
	Menu menu=new Menu("Biryani", 200);
		
		System.out.print("Name : "+customer.getName()+"\nCatering Status : "+catering.getCateringStatus()+"\nEvent Type : "+eventDetails.getTypeOfEvent()+"\nItem : "+menu.getNameOfItem());
	}

}
