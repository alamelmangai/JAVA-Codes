package com.cg.eventmanagement.beans;

public class EventDetails {
	private String city,state,country,typeOfEvent,eventFromDate,eventToDate;
	public EventDetails(String city, String state, String country, String typeOfEvent, String eventFromDate,
			String eventToDate, int pinCode, int eventCost, int noOfDays, int noOfAttendies) {
		super();
		this.city = city;
		this.state = state;
		this.country = country;
		this.typeOfEvent = typeOfEvent;
		this.eventFromDate = eventFromDate;
		this.eventToDate = eventToDate;
		this.pinCode = pinCode;
		this.eventCost = eventCost;
		this.noOfDays = noOfDays;
		this.noOfAttendies = noOfAttendies;
	}
	private int pinCode,eventCost,noOfDays,noOfAttendies;
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getTypeOfEvent() {
		return typeOfEvent;
	}
	public void setTypeOfEvent(String typeOfEvent) {
		this.typeOfEvent = typeOfEvent;
	}
	public String getEventFromDate() {
		return eventFromDate;
	}
	public void setEventFromDate(String eventFromDate) {
		this.eventFromDate = eventFromDate;
	}
	public String getEventToDate() {
		return eventToDate;
	}
	public void setEventToDate(String eventToDate) {
		this.eventToDate = eventToDate;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	public int getEventCost() {
		return eventCost;
	}
	public void setEventCost(int eventCost) {
		this.eventCost = eventCost;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public int getNoOfAttendies() {
		return noOfAttendies;
	}
	public void setNoOfAttendies(int noOfAttendies) {
		this.noOfAttendies = noOfAttendies;
	}

}
