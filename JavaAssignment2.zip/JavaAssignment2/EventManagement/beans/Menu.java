package com.cg.eventmanagement.beans;

public class Menu {
	private String nameOfItem;
	private int itemCost;
	public Menu(String nameOfItem, int itemCost) {
		super();
		this.nameOfItem = nameOfItem;
		this.itemCost = itemCost;
	}
	public String getNameOfItem() {
		return nameOfItem;
	}
	public void setNameOfItem(String nameOfItem) {
		this.nameOfItem = nameOfItem;
	}
	public int getItemCost() {
		return itemCost;
	}
	public void setItemCost(int itemCost) {
		this.itemCost = itemCost;
	}

}
