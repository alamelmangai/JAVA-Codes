package com.cg.library.beans;

public class Due {
	private int noOfDaysDelayed,duePerDay;
	private String dueStatus;
	public Due(int noOfDaysDelayed, int duePerDay, String dueStatus) {
		super();
		this.noOfDaysDelayed = noOfDaysDelayed;
		this.duePerDay = duePerDay;
		this.dueStatus = dueStatus;
	}
	public int getNoOfDaysDelayed() {
		return noOfDaysDelayed;
	}
	public void setNoOfDaysDelayed(int noOfDaysDelayed) {
		this.noOfDaysDelayed = noOfDaysDelayed;
	}
	public int getDuePerDay() {
		return duePerDay;
	}
	public void setDuePerDay(int duePerDay) {
		this.duePerDay = duePerDay;
	}
	public String getDueStatus() {
		return dueStatus;
	}
	public void setDueStatus(String dueStatus) {
		this.dueStatus = dueStatus;
	}
	

}
