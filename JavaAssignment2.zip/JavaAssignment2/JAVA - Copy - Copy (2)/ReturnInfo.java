package com.cg.library.beans;

public class ReturnInfo {
	private int dateOfReturn,returnStatus,returnedBookID;

	public ReturnInfo(int dateOfReturn, int returnStatus, int returnedBookID) {
		super();
		this.dateOfReturn = dateOfReturn;
		this.returnStatus = returnStatus;
		this.returnedBookID = returnedBookID;
	}

	public int getDateOfReturn() {
		return dateOfReturn;
	}

	public void setDateOfReturn(int dateOfReturn) {
		this.dateOfReturn = dateOfReturn;
	}

	public int getReturnStatus() {
		return returnStatus;
	}

	public void setReturnStatus(int returnStatus) {
		this.returnStatus = returnStatus;
	}

	public int getReturnedBookID() {
		return returnedBookID;
	}

	public void setReturnedBookID(int returnedBookID) {
		this.returnedBookID = returnedBookID;
	}
	

}
