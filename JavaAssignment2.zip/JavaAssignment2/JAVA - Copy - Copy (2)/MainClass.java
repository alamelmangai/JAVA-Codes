package com.cg.library.main;

import com.cg.library.beans.Address;
import com.cg.library.beans.BookDetails;
import com.cg.library.beans.Due;
import com.cg.library.beans.Issue;
import com.cg.library.beans.User;

public class MainClass {

	public static void main(String[] args) {
		User user = new User(22209876, 1001, "Deepak");
		Address address = new Address(600045, "Belgaum", "Karnataka", "India");
		BookDetails bookDetails = new BookDetails("story book", "C002GGH", "two states", "available", 20, 9, 2);
		Issue issue = new Issue("3-7-2018", "3-7-2018", "14-7-2018", "deepak", "Issued", "DGR1003");
		Due due = new Due(4, 20, "Pending");
		System.out.println(user.getUserName()+bookDetails.getBookName()+address.getCity()+issue.getBookIssueStatus()+due.getDueStatus());
	}

}
