package com.cg.library.beans;

public class Issue {
	private String issueDate,issueFromDate,issueToDate,issuedTo,bookIssueStatus,issuedBookID;

	public Issue(String issueDate, String issueFromDate, String issueToDate, String issuedTo, String bookIssueStatus,
			String issuedBookID) {
		super();
		this.issueDate = issueDate;
		this.issueFromDate = issueFromDate;
		this.issueToDate = issueToDate;
		this.issuedTo = issuedTo;
		this.bookIssueStatus = bookIssueStatus;
		this.issuedBookID = issuedBookID;
	}

	public String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getIssueFromDate() {
		return issueFromDate;
	}

	public void setIssueFromDate(String issueFromDate) {
		this.issueFromDate = issueFromDate;
	}

	public String getIssueToDate() {
		return issueToDate;
	}

	public void setIssueToDate(String issueToDate) {
		this.issueToDate = issueToDate;
	}

	public String getIssuedTo() {
		return issuedTo;
	}

	public void setIssuedTo(String issuedTo) {
		this.issuedTo = issuedTo;
	}

	public String getBookIssueStatus() {
		return bookIssueStatus;
	}

	public void setBookIssueStatus(String bookIssueStatus) {
		this.bookIssueStatus = bookIssueStatus;
	}

	public String getIssuedBookID() {
		return issuedBookID;
	}

	public void setIssuedBookID(String issuedBookID) {
		this.issuedBookID = issuedBookID;
	}


}
