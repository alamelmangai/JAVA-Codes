package com.cg.library.beans;

public class BookDetails {
	private String typeOfBook,bookID,bookName,bookAvailability;
	private int totNoOfBooks,NoOfBooksAvailable,NoOfBooksIssued;
	public BookDetails(String typeOfBook, String bookID, String bookName, String bookAvailability, int totNoOfBooks,
			int noOfBooksAvailable, int noOfBooksIssued) {
		super();
		this.typeOfBook = typeOfBook;
		this.bookID = bookID;
		this.bookName = bookName;
		this.bookAvailability = bookAvailability;
		this.totNoOfBooks = totNoOfBooks;
		NoOfBooksAvailable = noOfBooksAvailable;
		NoOfBooksIssued = noOfBooksIssued;
	}
	public String getTypeOfBook() {
		return typeOfBook;
	}
	public void setTypeOfBook(String typeOfBook) {
		this.typeOfBook = typeOfBook;
	}
	public String getBookID() {
		return bookID;
	}
	public void setBookID(String bookID) {
		this.bookID = bookID;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getBookAvailability() {
		return bookAvailability;
	}
	public void setBookAvailability(String bookAvailability) {
		this.bookAvailability = bookAvailability;
	}
	public int getTotNoOfBooks() {
		return totNoOfBooks;
	}
	public void setTotNoOfBooks(int totNoOfBooks) {
		this.totNoOfBooks = totNoOfBooks;
	}
	public int getNoOfBooksAvailable() {
		return NoOfBooksAvailable;
	}
	public void setNoOfBooksAvailable(int noOfBooksAvailable) {
		NoOfBooksAvailable = noOfBooksAvailable;
	}
	public int getNoOfBooksIssued() {
		return NoOfBooksIssued;
	}
	public void setNoOfBooksIssued(int noOfBooksIssued) {
		NoOfBooksIssued = noOfBooksIssued;
	}
	
}