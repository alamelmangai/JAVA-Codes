package com.cg.library.beans;

public class User {
	private int mobileNo,userID;
	private String userName;
	public User(int mobileNo, int userID, String userName) {
		super();
		this.mobileNo = mobileNo;
		this.userID = userID;
		this.userName = userName;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}


}
