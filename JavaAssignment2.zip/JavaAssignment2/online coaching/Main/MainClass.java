package com.cg.OnlineCoaching.Main;

import com.cg.OnlineCoaching.bean.Address;
import com.cg.OnlineCoaching.bean.Admission;
import com.cg.OnlineCoaching.bean.CourseDetails;
import com.cg.OnlineCoaching.bean.Discount;
import com.cg.OnlineCoaching.bean.PaymentDetails;
import com.cg.OnlineCoaching.bean.StudentDetails;

public class MainClass {

	public static void main(String[] args) {
		StudentDetails studentDetails = new StudentDetails(9448744693l, "Aishwarya", "Patil");
		Admission admission = new Admission("25/04/2018", "paid", 1500);
		CourseDetails courseDetails = new CourseDetails("Fulltime", 1500, "Java", "01/05/2018", "29/05/2018", 29);
		
		System.out.println("Student Name: "+ studentDetails.getFirstName()+" "+studentDetails.getLastName()+" " +"Course type:" +courseDetails.getCostofcourse()+" "+"course start and end date:"+courseDetails.getStartingDate()+" "+courseDetails.getEndingDate());
		
				
	}

}
