package com.cg.OnlineCoaching.bean;

public class PaymentDetails {
	private String TypeOfPayment,PaymentStatus,PaymentDate;
	private int PaymentAmount;
	public PaymentDetails(String typeOfPayment, String paymentStatus, String paymentDate, int paymentAmount) {
		super();
		TypeOfPayment = typeOfPayment;
		PaymentStatus = paymentStatus;
		PaymentDate = paymentDate;
		PaymentAmount = paymentAmount;
	}
	public String getTypeOfPayment() {
		return TypeOfPayment;
	}
	public void setTypeOfPayment(String typeOfPayment) {
		TypeOfPayment = typeOfPayment;
	}
	public String getPaymentStatus() {
		return PaymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		PaymentStatus = paymentStatus;
	}
	public String getPaymentDate() {
		return PaymentDate;
	}
	public void setPaymentDate(String paymentDate) {
		PaymentDate = paymentDate;
	}
	public int getPaymentAmount() {
		return PaymentAmount;
	}
	public void setPaymentAmount(int paymentAmount) {
		PaymentAmount = paymentAmount;
	}
	

}
