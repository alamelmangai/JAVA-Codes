package com.cg.OnlineCoaching.bean;

public class CourseDetails {
	private String Typeofcourse,Nameofcourse,StartingDate,EndingDate;
	private int noOfDays,Costofcourse;
	public CourseDetails(String typeofcourse, int costofcourse, String nameofcourse, String startingDate,
			String endingDate, int noOfDays) {
		super();
		Typeofcourse = typeofcourse;
		Costofcourse = costofcourse;
		Nameofcourse = nameofcourse;
		StartingDate = startingDate;
		EndingDate = endingDate;
		this.noOfDays = noOfDays;
	}
	public String getTypeofcourse() {
		return Typeofcourse;
	}
	public void setTypeofcourse(String typeofcourse) {
		Typeofcourse = typeofcourse;
	}
	public int getCostofcourse() {
		return Costofcourse;
	}
	public void setCostofcourse(int costofcourse) {
		Costofcourse = costofcourse;
	}
	public String getNameofcourse() {
		return Nameofcourse;
	}
	public void setNameofcourse(String nameofcourse) {
		Nameofcourse = nameofcourse;
	}
	public String getStartingDate() {
		return StartingDate;
	}
	public void setStartingDate(String startingDate) {
		StartingDate = startingDate;
	}
	public String getEndingDate() {
		return EndingDate;
	}
	public void setEndingDate(String endingDate) {
		EndingDate = endingDate;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	
	
}
