package com.cg.OnlineCoaching.bean;

public class Discount {
	private String TypeofDiscount,DiscountAvailability,DiscountDateDeadline,DiscountCode;

	public Discount(String typeofDiscount, String discountAvailability, String discountDateDeadline,
			String discountCode) {
		super();
		TypeofDiscount = typeofDiscount;
		DiscountAvailability = discountAvailability;
		DiscountDateDeadline = discountDateDeadline;
		DiscountCode = discountCode;
	}

	public String getTypeofDiscount() {
		return TypeofDiscount;
	}

	public void setTypeofDiscount(String typeofDiscount) {
		TypeofDiscount = typeofDiscount;
	}

	public String getDiscountAvailability() {
		return DiscountAvailability;
	}

	public void setDiscountAvailability(String discountAvailability) {
		DiscountAvailability = discountAvailability;
	}

	public String getDiscountDateDeadline() {
		return DiscountDateDeadline;
	}

	public void setDiscountDateDeadline(String discountDateDeadline) {
		DiscountDateDeadline = discountDateDeadline;
	}

	public String getDiscountCode() {
		return DiscountCode;
	}

	public void setDiscountCode(String discountCode) {
		DiscountCode = discountCode;
	}
	
}
