package com.cg.OnlineCoaching.bean;

public class Admission {
	private String DateofAdmission,FeesStatus;
	private int FeesAmount;
	public Admission(String dateofAdmission, String feesStatus, int feesAmount) {
		super();
		DateofAdmission = dateofAdmission;
		FeesStatus = feesStatus;
		FeesAmount = feesAmount;
	}
	public String getDateofAdmission() {
		return DateofAdmission;
	}
	public void setDateofAdmission(String dateofAdmission) {
		DateofAdmission = dateofAdmission;
	}
	public String getFeesStatus() {
		return FeesStatus;
	}
	public void setFeesStatus(String feesStatus) {
		FeesStatus = feesStatus;
	}
	public int getFeesAmount() {
		return FeesAmount;
	}
	public void setFeesAmount(int feesAmount) {
		FeesAmount = feesAmount;
	}
	
}