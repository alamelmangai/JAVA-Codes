package com.cg.railwayreservation.beans;

public class TrainInfo {
	private String trainName;
	private int trainNo,noOfSeatsOccupied;
	public TrainInfo(String trainName, int trainNo, int noOfSeatsOccupied) {
		super();
		this.trainName = trainName;
		this.trainNo = trainNo;
		this.noOfSeatsOccupied = noOfSeatsOccupied;
	}
	public String getTrainName() {
		return trainName;
	}
	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}
	public int getTrainNo() {
		return trainNo;
	}
	public void setTrainNo(int trainNo) {
		this.trainNo = trainNo;
	}
	public int getNoOfSeatsOccupied() {
		return noOfSeatsOccupied;
	}
	public void setNoOfSeatsOccupied(int noOfSeatsOccupied) {
		this.noOfSeatsOccupied = noOfSeatsOccupied;
	}
	
}