package com.cg.railwayreservation.beans;

public class Cancellaion {
	private int cancellationCharges,percentageofCancellationperdayafterdeadline;
	private String deadlineDate;
	public Cancellaion(int cancellationCharges, int percentageofCancellationperdayafterdeadline, String deadlineDate) {
		super();
		this.cancellationCharges = cancellationCharges;
		this.percentageofCancellationperdayafterdeadline = percentageofCancellationperdayafterdeadline;
		this.deadlineDate = deadlineDate;
	}
	public int getCancellationCharges() {
		return cancellationCharges;
	}
	public void setCancellationCharges(int cancellationCharges) {
		this.cancellationCharges = cancellationCharges;
	}
	public int getPercentageofCancellationperdayafterdeadline() {
		return percentageofCancellationperdayafterdeadline;
	}
	public void setPercentageofCancellationperdayafterdeadline(int percentageofCancellationperdayafterdeadline) {
		this.percentageofCancellationperdayafterdeadline = percentageofCancellationperdayafterdeadline;
	}
	public String getDeadlineDate() {
		return deadlineDate;
	}
	public void setDeadlineDate(String deadlineDate) {
		this.deadlineDate = deadlineDate;
	}
	
	
}
