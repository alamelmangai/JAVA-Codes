package com.cg.railwayreservation.beans;

public class NumberOfPassenger {
	private int adult,child;

	public NumberOfPassenger(int adult, int child) {
		super();
		this.adult = adult;
		this.child = child;
	}

	public int getAdult() {
		return adult;
	}

	public void setAdult(int adult) {
		this.adult = adult;
	}

	public int getChild() {
		return child;
	}

	public void setChild(int child) {
		this.child = child;
	}
	

}
