package com.cg.railwayreservation.beans;

public class Ticket {
	private int totCost,subtotal,stateGST,centralGST,serviceTax,seatNumber;
    private String PNR,boogieNumber;
	public Ticket(int totCost, int subtotal, int stateGST, int centralGST, int serviceTax, int seatNumber, String pNR,
			String boogieNumber) {
		super();
		this.totCost = totCost;
		this.subtotal = subtotal;
		this.stateGST = stateGST;
		this.centralGST = centralGST;
		this.serviceTax = serviceTax;
		this.seatNumber = seatNumber;
		PNR = pNR;
		this.boogieNumber = boogieNumber;
	}
	public int getTotCost() {
		return totCost;
	}
	public void setTotCost(int totCost) {
		this.totCost = totCost;
	}
	public int getSubtotal() {
		return subtotal;
	}
	public void setSubtotal(int subtotal) {
		this.subtotal = subtotal;
	}
	public int getStateGST() {
		return stateGST;
	}
	public void setStateGST(int stateGST) {
		this.stateGST = stateGST;
	}
	public int getCentralGST() {
		return centralGST;
	}
	public void setCentralGST(int centralGST) {
		this.centralGST = centralGST;
	}
	public int getServiceTax() {
		return serviceTax;
	}
	public void setServiceTax(int serviceTax) {
		this.serviceTax = serviceTax;
	}
	public int getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}
	public String getPNR() {
		return PNR;
	}
	public void setPNR(String pNR) {
		PNR = pNR;
	}
	public String getBoogieNumber() {
		return boogieNumber;
	}
	public void setBoogieNumber(String boogieNumber) {
		this.boogieNumber = boogieNumber;
	}
    

}
