package com.cg.railwayreservation.beans;

public class BookingDetails {
	private String from,to,startTime,endTime,typeOfBhogi;
    private int ticketCost;
	public BookingDetails(String from, String to, String startTime, String endTime, String typeOfBhogi,
			int ticketCost) {
		super();
		this.from = from;
		this.to = to;
		this.startTime = startTime;
		this.endTime = endTime;
		this.typeOfBhogi = typeOfBhogi;
		this.ticketCost = ticketCost;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getTypeOfBhogi() {
		return typeOfBhogi;
	}
	public void setTypeOfBhogi(String typeOfBhogi) {
		this.typeOfBhogi = typeOfBhogi;
	}
	public int getTicketCost() {
		return ticketCost;
	}
	public void setTicketCost(int ticketCost) {
		this.ticketCost = ticketCost;
	}

}