package com.cg.railwayreservation.main;

import com.cg.railwayreservation.beans.Transaction;
import com.cg.railwayreservation.beans.BookingDetails;
import com.cg.railwayreservation.beans.Cancellaion;
import com.cg.railwayreservation.beans.NumberOfPassenger;
import com.cg.railwayreservation.beans.Passenger;
import com.cg.railwayreservation.beans.Ticket;
import com.cg.railwayreservation.beans.TrainInfo;

public class MainClass {

	public static void main(String[] args) {
		Passenger passenger = new Passenger(22208765, 22, 22345123, "Female", "Aishu");
		NumberOfPassenger numberOfPassenger = new NumberOfPassenger( 2, 2);
		BookingDetails bookingDetails = new BookingDetails("Chennai", "pune", "12:30","22:45", "NonAC", 1200);
		Transaction transaction = new Transaction("Card", "Success", "12-8-2018", 540);
		TrainInfo trainInfo = new TrainInfo("Chennai Mail",12341 , 43);
		Cancellaion cancellaion = new Cancellaion(1000, 30, "20-09-2018");
		Ticket ticket = new Ticket(2000, 1500, 20, 20, 500, 23, "TRSIN231", "S1");
		System.out.println(passenger.getAadharCard()+bookingDetails.getFrom()+trainInfo.getTrainName()+cancellaion.getCancellationCharges()+ticket.getBoogieNumber()+transaction.getTransactionAmount());
		  
		
	}

}
