package com.cg.railwayreservation.beans;

public class Passenger {
	private int mobileNo,age,aadharCard;
	private String name,gender;
	public Passenger(int mobileNo, int age, int aadharCard, String name, String gender) {
		super();
		this.mobileNo = mobileNo;
		this.age = age;
		this.aadharCard = aadharCard;
		this.name = name;
		this.gender = gender;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getAadharCard() {
		return aadharCard;
	}
	public void setAadharCard(int aadharCard) {
		this.aadharCard = aadharCard;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}

}