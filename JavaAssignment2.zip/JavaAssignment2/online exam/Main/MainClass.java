package com.cg.OnlineExam.Main;

import com.cg.OnlineExam.bean.Candiadte;
import com.cg.OnlineExam.bean.ExamDetail;
import com.cg.OnlineExam.bean.Result;
import com.cg.OnlineExam.bean.SubjectType;

public class MainClass {

	public static void main(String[] args) {
		Candiadte candiadte = new Candiadte(23, 9874563215l, "Aishwarya", "Patil", "AVU565W", "BE", "Female", "aishu@abc.com");
		SubjectType subjectType = new SubjectType(60, "JAVA", "JV123");
		Result result = new Result(55, 91.66, "A", "Pass");
		System.out.println("Candiadte Name:"+" "+candiadte.getFirstName()+" "+candiadte.getLastName()+" Qualification:"+" "+candiadte.getQualification()+" "+"Percentage:"+result.getPercScored()+" "+"Result status:"+result.getResultStatus() );

	}

}
