package com.cg.OnlineExam.bean;

public class ExamDetail {
	private int examFee,totNoOfQuestion;
	private String date,duration,time,location;
	public ExamDetail(int examFee, int totNoOfQuestion, String date, String duration, String time, String location) {
		super();
		this.examFee = examFee;
		this.totNoOfQuestion = totNoOfQuestion;
		this.date = date;
		this.duration = duration;
		this.time = time;
		this.location = location;
	}
	public int getExamFee() {
		return examFee;
	}
	public void setExamFee(int examFee) {
		this.examFee = examFee;
	}
	public int getTotNoOfQuestion() {
		return totNoOfQuestion;
	}
	public void setTotNoOfQuestion(int totNoOfQuestion) {
		this.totNoOfQuestion = totNoOfQuestion;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
}
