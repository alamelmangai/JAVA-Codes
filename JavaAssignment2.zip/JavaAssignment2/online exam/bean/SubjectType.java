package com.cg.OnlineExam.bean;

public class SubjectType {
	private int noOfQue;
	private String subjName,subjId;
	public SubjectType(int noOfQue, String subjName, String subjId) {
		super();
		this.noOfQue = noOfQue;
		this.subjName = subjName;
		this.subjId = subjId;
	}
	public int getNoOfQue() {
		return noOfQue;
	}
	public void setNoOfQue(int noOfQue) {
		this.noOfQue = noOfQue;
	}
	public String getSubjName() {
		return subjName;
	}
	public void setSubjName(String subjName) {
		this.subjName = subjName;
	}
	public String getSubjId() {
		return subjId;
	}
	public void setSubjId(String subjId) {
		this.subjId = subjId;
	}
	

}
