package com.cg.OnlineExam.bean;

public class Result {
	private int noOfQAttempted;
	private double percScored;
	private String gradeObt,resultStatus;
	public Result(int noOfQAttempted, double percScored, String gradeObt, String resultStatus) {
		super();
		this.noOfQAttempted = noOfQAttempted;
		this.percScored = percScored;
		this.gradeObt = gradeObt;
		this.resultStatus = resultStatus;
	}
	public int getNoOfQAttempted() {
		return noOfQAttempted;
	}
	public void setNoOfQAttempted(int noOfQAttempted) {
		this.noOfQAttempted = noOfQAttempted;
	}
	public double getPercScored() {
		return percScored;
	}
	public void setPercScored(double percScored) {
		this.percScored = percScored;
	}
	public String getGradeObt() {
		return gradeObt;
	}
	public void setGradeObt(String gradeObt) {
		this.gradeObt = gradeObt;
	}
	public String getResultStatus() {
		return resultStatus;
	}
	public void setResultStatus(String resultStatus) {
		this.resultStatus = resultStatus;
	}
	
}
