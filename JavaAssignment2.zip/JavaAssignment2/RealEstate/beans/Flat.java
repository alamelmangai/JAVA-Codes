package com.cg.realestate.beans;

public class Flat {
	private int flatNo,flatCost;
	private String typeofFlat,measurement,typeofSelling;
	public Flat(int flatNo, int flatCost, String typeofFlat, String measurement, String typeofSelling) {
		super();
		this.flatNo = flatNo;
		this.flatCost = flatCost;
		this.typeofFlat = typeofFlat;
		this.measurement = measurement;
		this.typeofSelling = typeofSelling;
	}
	public int getFlatNo() {
		return flatNo;
	}
	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}
	public int getFlatCost() {
		return flatCost;
	}
	public void setFlatCost(int flatCost) {
		this.flatCost = flatCost;
	}
	public String getTypeofFlat() {
		return typeofFlat;
	}
	public void setTypeofFlat(String typeofFlat) {
		this.typeofFlat = typeofFlat;
	}
	public String getMeasurement() {
		return measurement;
	}
	public void setMeasurement(String measurement) {
		this.measurement = measurement;
	}
	public String getTypeofSelling() {
		return typeofSelling;
	}
	public void setTypeofSelling(String typeofSelling) {
		this.typeofSelling = typeofSelling;
	}

}
