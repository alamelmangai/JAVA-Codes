package com.cg.realestate.beans;

public class Seller {
	private String nameOfSeller;
	private long mobileno;
	public Seller(String nameOfSeller, long mobileno) {
		super();
		this.nameOfSeller = nameOfSeller;
		this.mobileno = mobileno;
	}
	public String getNameOfSeller() {
		return nameOfSeller;
	}
	public void setNameOfSeller(String nameOfSeller) {
		this.nameOfSeller = nameOfSeller;
	}
	public long getMobileno() {
		return mobileno;
	}
	public void setMobileno(long mobileno) {
		this.mobileno = mobileno;
	}
	
}
