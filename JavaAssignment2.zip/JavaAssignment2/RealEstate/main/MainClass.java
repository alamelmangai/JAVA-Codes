package com.cg.realestate.main;

import com.cg.realestate.beans.Flat;
import com.cg.realestate.beans.FlatLocation;
import com.cg.realestate.beans.Loan;
import com.cg.realestate.beans.Seller;

public class MainClass {

	public static void main(String[] args) {
		Flat flat=new Flat(120, 2800000, "2 BHK", "NA", "Sell");
		Loan loan=new Loan("Yes", 500000, 70000, 12);
		Seller seller=new Seller("Rakesh", 9876543216l);
		FlatLocation flatLocation=new FlatLocation("Pune", "Maharashtra", "India", 411062);
		System.out.println("Flat Type : "+flat.getTypeofFlat()+"\nSeller Name : "+seller.getNameOfSeller());
	}

}
