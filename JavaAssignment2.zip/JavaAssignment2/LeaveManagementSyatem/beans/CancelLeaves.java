package com.cg.leavemanagementsystem.beans;

public class CancelLeaves {
	private String reasonOfCancellation,cancellationStatus;

	public CancelLeaves(String reasonOfCancellation, String cancellationStatus) {
		super();
		this.reasonOfCancellation = reasonOfCancellation;
		this.cancellationStatus = cancellationStatus;
	}

	public String getReasonOfCancellation() {
		return reasonOfCancellation;
	}

	public void setReasonOfCancellation(String reasonOfCancellation) {
		this.reasonOfCancellation = reasonOfCancellation;
	}

	public String getCancellationStatus() {
		return cancellationStatus;
	}

	public void setCancellationStatus(String cancellationStatus) {
		this.cancellationStatus = cancellationStatus;
	}
	
}
