package com.cg.leavemanagementsystem.beans;

public class LeaveDetails {
	private int totNoOfLeaves,leavestaken,leavesRemained;
	private String leaveType;
	public LeaveDetails(int totNoOfLeaves, int leavestaken, int leavesRemained, String leaveType) {
		super();
		this.totNoOfLeaves = totNoOfLeaves;
		this.leavestaken = leavestaken;
		this.leavesRemained = leavesRemained;
		this.leaveType = leaveType;
	}
	public int getTotNoOfLeaves() {
		return totNoOfLeaves;
	}
	public void setTotNoOfLeaves(int totNoOfLeaves) {
		this.totNoOfLeaves = totNoOfLeaves;
	}
	public int getLeavestaken() {
		return leavestaken;
	}
	public void setLeavestaken(int leavestaken) {
		this.leavestaken = leavestaken;
	}
	public int getLeavesRemained() {
		return leavesRemained;
	}
	public void setLeavesRemained(int leavesRemained) {
		this.leavesRemained = leavesRemained;
	}
	public String getLeaveType() {
		return leaveType;
	}
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	
}
