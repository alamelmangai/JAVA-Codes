package com.cg.leavemanagementsystem.beans;

public class ApplyLeaves {
	private int noOfLeavesApplied;
	private String leaveStatus,fromDate,toDate,reasonOfLeave;
	public ApplyLeaves(int noOfLeavesApplied, String leaveStatus, String fromDate, String toDate,
			String reasonOfLeave) {
		super();
		this.noOfLeavesApplied = noOfLeavesApplied;
		this.leaveStatus = leaveStatus;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.reasonOfLeave = reasonOfLeave;
	}
	public int getNoOfLeavesApplied() {
		return noOfLeavesApplied;
	}
	public void setNoOfLeavesApplied(int noOfLeavesApplied) {
		this.noOfLeavesApplied = noOfLeavesApplied;
	}
	public String getLeaveStatus() {
		return leaveStatus;
	}
	public void setLeaveStatus(String leaveStatus) {
		this.leaveStatus = leaveStatus;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getReasonOfLeave() {
		return reasonOfLeave;
	}
	public void setReasonOfLeave(String reasonOfLeave) {
		this.reasonOfLeave = reasonOfLeave;
	}

}
