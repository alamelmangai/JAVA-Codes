package com.cg.leavemanagementsystem.main;

import com.cg.leavemanagementsystem.beans.ApplyLeaves;
import com.cg.leavemanagementsystem.beans.CancelLeaves;
import com.cg.leavemanagementsystem.beans.Employee;
import com.cg.leavemanagementsystem.beans.LeaveDetails;

public class MainClass {

	public static void main(String[] args) {
		Employee employee=new Employee("Ramesh", 12345);
		CancelLeaves cancelLeaves=new CancelLeaves("Wedding date changes", "In progress");
		ApplyLeaves applyLeaves=new ApplyLeaves(3, "In progress", "09/05/2018", "12/05/2018", "Friend's wedding");
		LeaveDetails leaveDetails=new LeaveDetails(6, 3, 3, "Advanced");
		System.out.println("Employee Name : "+employee.getEmpName()+"\nLeaves Applied : "+leaveDetails.getLeavestaken());
	}

}
